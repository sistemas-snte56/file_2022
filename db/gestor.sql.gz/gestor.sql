-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 13-06-2022 a las 18:06:41
-- Versión del servidor: 10.4.24-MariaDB
-- Versión de PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `gestor`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_archivos`
--

CREATE TABLE `tbl_archivos` (
  `id_archivo` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_categoria` int(11) DEFAULT NULL,
  `nombre` varchar(255) DEFAULT NULL,
  `tipo` varchar(255) DEFAULT NULL,
  `ruta` text DEFAULT NULL,
  `fecha` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tbl_archivos`
--

INSERT INTO `tbl_archivos` (`id_archivo`, `id_usuario`, `id_categoria`, `nombre`, `tipo`, `ruta`, `fecha`) VALUES
(6, 11, 22, 'java1.png', 'png', '../../archivos/11/java1.png', '2022-06-10 11:53:16'),
(7, 11, 22, 'java2.png', 'png', '../../archivos/11/java2.png', '2022-06-10 11:53:16'),
(8, 11, 22, 'IMG_5846.PNG', 'PNG', '../../archivos/11/IMG_5846.PNG', '2022-06-10 11:55:23'),
(9, 11, 24, 'jquery.png', 'png', '../../archivos/11/jquery.png', '2022-06-10 12:18:44'),
(10, 11, 22, 'yoga1.jpg', 'jpg', '../../archivos/11/yoga1.jpg', '2022-06-10 12:35:59'),
(11, 11, 22, 'Cotizacion Internet Dedicado y Simetrico_SNTE (1).pdf', 'pdf', '../../archivos/11/Cotizacion Internet Dedicado y Simetrico_SNTE (1).pdf', '2022-06-10 13:20:15'),
(12, 11, 25, 'PUNTO DE ACCESO  WiFi GRANDSTREAM GRADO INDUSTRIAL MAS DE 100 DISPOSITIVOS (1).pdf', 'pdf', '../../archivos/11/PUNTO DE ACCESO  WiFi GRANDSTREAM GRADO INDUSTRIAL MAS DE 100 DISPOSITIVOS (1).pdf', '2022-06-10 13:21:59'),
(13, 20, 30, 'car-30984__340.png', 'png', '../../archivos/20/car-30984__340.png', '2022-06-10 13:30:23'),
(14, 20, 30, 'car-63930__480.jpg', 'jpg', '../../archivos/20/car-63930__480.jpg', '2022-06-10 13:30:23'),
(15, 20, 30, 'car-604019__340.png', 'png', '../../archivos/20/car-604019__340.png', '2022-06-10 13:30:23'),
(16, 20, 30, 'car-4361321__340.png', 'png', '../../archivos/20/car-4361321__340.png', '2022-06-10 13:30:23'),
(18, 17, 31, 'ANEXO I 56-01.jpg', 'jpg', '../../archivos/17/ANEXO I 56-01.jpg', '2022-06-10 14:55:17'),
(19, 17, 31, 'ANEXO I 56-02.jpg', 'jpg', '../../archivos/17/ANEXO I 56-02.jpg', '2022-06-10 14:55:17'),
(20, 17, 31, 'Sin título-1-01.jpg', 'jpg', '../../archivos/17/Sin título-1-01.jpg', '2022-06-10 14:55:17'),
(21, 17, 31, 'Sin título-1-02.jpg', 'jpg', '../../archivos/17/Sin título-1-02.jpg', '2022-06-10 14:55:17'),
(22, 17, 31, 'Sin título-1-03.jpg', 'jpg', '../../archivos/17/Sin título-1-03.jpg', '2022-06-10 14:55:17'),
(23, 17, 31, 'Sin título-1-04.jpg', 'jpg', '../../archivos/17/Sin título-1-04.jpg', '2022-06-10 14:55:17'),
(27, 18, 2, 'Sin título-1-30.jpg', 'jpg', '../../archivos/18/Sin título-1-30.jpg', '2022-06-13 09:39:06'),
(28, 18, 2, 'Sin título-1-31.jpg', 'jpg', '../../archivos/18/Sin título-1-31.jpg', '2022-06-13 09:39:06'),
(29, 18, 2, 'Sin título-1-32.jpg', 'jpg', '../../archivos/18/Sin título-1-32.jpg', '2022-06-13 09:39:06'),
(30, 18, 2, 'Sin título-1-33.jpg', 'jpg', '../../archivos/18/Sin título-1-33.jpg', '2022-06-13 09:39:06'),
(31, 18, 2, 'LOGO.pdf', 'pdf', '../../archivos/18/LOGO.pdf', '2022-06-13 09:47:36'),
(32, 18, 2, 'add.png', 'png', '../../archivos/18/add.png', '2022-06-13 09:49:57'),
(33, 18, 2, 'Cómic Agradecimiento a los Maestros Ideas Imagen para Blog.pdf', 'pdf', '../../archivos/18/Cómic Agradecimiento a los Maestros Ideas Imagen para Blog.pdf', '2022-06-13 09:53:16');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_categorias`
--

CREATE TABLE `tbl_categorias` (
  `id_categoria` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `fechaInsert` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tbl_categorias`
--

INSERT INTO `tbl_categorias` (`id_categoria`, `id_usuario`, `nombre`, `fechaInsert`) VALUES
(1, 14, '01.ENERO.2022', '2022-06-03 17:01:45'),
(2, 18, 'MÚSICA', '2022-06-03 17:35:55'),
(3, 18, 'LIBROS', '2022-06-03 17:36:05'),
(4, 18, 'YOGA', '2022-06-03 17:36:17'),
(5, 18, 'COCINA', '2022-06-03 17:36:24'),
(6, 18, 'VIAJES', '2022-06-03 17:36:32'),
(7, 19, 'ARTE', '2022-06-03 17:41:04'),
(8, 19, 'DISEÑO', '2022-06-03 17:41:09'),
(9, 10, 'ROPA', '2022-06-03 18:36:16'),
(10, 10, 'ZAPATOS', '2022-06-03 18:36:23'),
(11, 10, 'MUEBLES', '2022-06-03 18:36:33'),
(18, 19, 'EDUCACION', '2022-06-06 13:37:55'),
(21, 19, 'FOTOGRAFÍA', '2022-06-06 14:38:51'),
(22, 11, 'JAVA', '2022-06-06 14:50:50'),
(23, 11, 'PHP', '2022-06-06 14:50:55'),
(24, 11, 'JQUERY', '2022-06-06 14:51:00'),
(25, 11, 'C  PLUS PLUS', '2022-06-06 14:51:07'),
(27, 15, 'Vinculación Social', '2022-06-08 10:32:42'),
(28, 15, 'Equidad', '2022-06-08 10:32:52'),
(29, 15, 'Género y Derechos Humanos', '2022-06-08 10:33:05'),
(30, 20, 'Carros', '2022-06-10 13:29:59'),
(31, 17, 'ANEXO I DOCENTES DE EDUCACIÓN BÁSICA', '2022-06-10 14:54:27');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_usuarios`
--

CREATE TABLE `tbl_usuarios` (
  `id_usuario` int(11) NOT NULL,
  `nombre` varchar(220) DEFAULT NULL,
  `apaterno` varchar(220) DEFAULT NULL,
  `materno` varchar(220) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `email` varchar(220) DEFAULT NULL,
  `usuario` varchar(220) DEFAULT NULL,
  `password` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tbl_usuarios`
--

INSERT INTO `tbl_usuarios` (`id_usuario`, `nombre`, `apaterno`, `materno`, `fecha`, `email`, `usuario`, `password`, `date`) VALUES
(1, 'Florencia', 'Patzzani', 'Lascano', '1985-06-22', 'florencia@email.com', 'florencia', 'ddaa02864ebb18e56b6422e2d7cf7df4af18d6ee', '2022-05-30 19:15:06'),
(2, 'Patricia', 'Alarcon', 'Suarez', '1986-02-11', 'paty@email.com', 'paty', '6f1f8bd9bb2c4d807cccb8995cd712afa6c497a1', '2022-05-30 19:16:29'),
(3, 'Vladimir', 'Aparicio', 'Lopez', '1977-03-21', 'vladi@email.com', 'vladi', '72244a75f1ff6bd906949dc3953433e996461f1a', '2022-05-30 19:17:58'),
(4, 'Enrique', 'Garcia', 'Abad', '1984-06-22', 'quique@email.com', 'quique', '10486251ef8ca01f4c3b9fec597baa1a2cefdae1', '2022-05-30 19:28:44'),
(5, 'Efrain', 'Gastin', 'Gomour', '1988-12-28', 'efra@email.com', 'efra', '755aa24f5d66317b9edfa49486ec2723a944fc93', '2022-05-30 19:39:15'),
(6, 'Maria Patricia', 'Juarez', 'Francisco', '1988-02-28', 'paty@email.com', 'paty2', '0006648c1f048c4badc05210fe6ca217e80f9d7e', '2022-05-30 19:41:30'),
(7, 'Luis Enrique', 'Soto', 'Luna', '1984-07-23', 'quique2@email.com', 'enrique', '4452c88f01f0d61e51249dda699e3b7cbe5f438e', '2022-05-30 19:43:42'),
(8, 'Nestor', 'Galindo', 'Herrera', '1981-12-02', 'nestor@email.com', 'neto', 'neto', '2022-05-30 23:15:12'),
(9, 'Ernesto', 'Medina', 'Flores', '1977-12-02', 'neto@email.com', 'neto.medina', 'b314e0f14136dd1d789c78f8c288487f5c267c87', '2022-05-30 19:47:43'),
(10, 'Viridiana', 'Triguero', 'Molina', '1985-03-22', 'viry@email.com', 'viry', 'dbf8de2aab30ec51b2e3ddf4e694a3988559884d', '2022-05-30 19:48:44'),
(11, 'Virguinia', 'Lagunes', 'Rosado', '1979-06-21', 'vicky@email.com', 'vicky', 'e79cab55eab4c0a1a63610829a51fd51d5cfb294', '2022-05-30 19:50:01'),
(12, 'Elena', 'Díaz', 'Pazzini', '0000-00-00', 'elena@example.com', 'elena', '291c6b2df1bac379d47f5557f9e564a1f6618bf7', '2022-05-30 20:07:56'),
(13, 'Esther', 'Ceja', 'Perez', '0000-00-00', 'esther@example.com', 'tete', '3105221c1c15399d170ef540e974ef4f37f84e93', '2022-05-30 20:31:15'),
(14, 'Juan Manuel', 'Mendez', 'Aparicio', '2012-05-09', 'juanma@email.com', 'juanma', '06a7d69a0f4729ee1b5a8978fc04d75388c13448', '2022-05-30 20:35:39'),
(15, 'Miriam de los Angeles', 'Garcia', 'Medina', '1974-01-09', 'miri@email.com', 'miri', 'eb286b121fc8a496e3f515a61ff6b43e22ff1228', '2022-05-30 22:19:46'),
(16, 'Juan Manuel', 'Avendaño', 'lopez', '2022-05-05', 'juanmm@email.com', 'juanmae', '34100949e24c92d0198aaab7e9f371507d0ed4d8', '2022-05-30 22:20:24'),
(17, 'Edgardo', 'Luna', 'Alvarado', '1982-01-20', 'edgardo@email.com', 'edgardo', '41b864e849659576b85cc50d1b7f39d40150a62c', '2022-05-31 15:40:29'),
(18, 'Miroslava', 'Hernandez ', 'de la Merced', '1984-10-04', 'meche@email.com', 'miros', '907842346560471fb02d29dfef52693ee9e221b7', '2022-05-31 20:41:59'),
(19, 'Valentina', 'Avila', 'Sousa', '2013-06-11', 'vale@email.com', 'vale', '24c4de7fefa3d80bda04c5b68c8042e60fc15083', '2022-06-03 19:46:08'),
(20, 'Uriel', 'Medina', 'Lopez', '2022-06-15', 'uriel@example.com', 'uriel', '878b7308f305c51ab1acbaa985092d8698a63e54', '2022-06-10 18:27:40');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `tbl_archivos`
--
ALTER TABLE `tbl_archivos`
  ADD PRIMARY KEY (`id_archivo`),
  ADD KEY `fkArchivosCategorias_idx` (`id_categoria`),
  ADD KEY `fkUsuariosArchivos_idx` (`id_usuario`);

--
-- Indices de la tabla `tbl_categorias`
--
ALTER TABLE `tbl_categorias`
  ADD PRIMARY KEY (`id_categoria`),
  ADD KEY `fkCategoriaUsuario_idx` (`id_usuario`);

--
-- Indices de la tabla `tbl_usuarios`
--
ALTER TABLE `tbl_usuarios`
  ADD PRIMARY KEY (`id_usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `tbl_archivos`
--
ALTER TABLE `tbl_archivos`
  MODIFY `id_archivo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT de la tabla `tbl_categorias`
--
ALTER TABLE `tbl_categorias`
  MODIFY `id_categoria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT de la tabla `tbl_usuarios`
--
ALTER TABLE `tbl_usuarios`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `tbl_archivos`
--
ALTER TABLE `tbl_archivos`
  ADD CONSTRAINT `fkArchivosCategorias` FOREIGN KEY (`id_categoria`) REFERENCES `tbl_categorias` (`id_categoria`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fkUsuariosArchivos` FOREIGN KEY (`id_usuario`) REFERENCES `tbl_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `tbl_categorias`
--
ALTER TABLE `tbl_categorias`
  ADD CONSTRAINT `tbl_categorias_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `tbl_usuarios` (`id_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
